public interface DatabaseOBJ {
    String lineRepresentation();
    String getSearchKey();
}
